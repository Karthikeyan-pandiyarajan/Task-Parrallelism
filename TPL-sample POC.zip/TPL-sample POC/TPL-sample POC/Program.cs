﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace TPL_sample_POC
{
	class Program
	{
		
		static void Main(string[] args)
		{
			//string parallelPath = @"C:\Karthikeyan\TPL test\parallel";
			//Test();

			Console.WriteLine(DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss"));
			Console.WriteLine("parallel creating files started");
			//ErrorCheck();
			var demo = new DataflowDemo();
			var folderTask1 = demo.CalculateTotalSizeAsync("");
			Task.WhenAll(folderTask1).Wait();
			var totalSize = demo.GetTotalSizeAsync().Result;
			Console.WriteLine(DateTime.Now.ToString());
			
			Console.ReadLine();
		}

		private static  async void ErrorCheck()
		{
			try
			{
				await Err();
			}
			catch(Exception e)
			{

			}
			
		}

		private static Task Err()
		{
			return Task.Run(() => 
			{
				for(int i =0; i<10; i++)
				{
					if(i == 0)
					{
						throw new ArgumentNullException("null");
					}
				}
			});
		}

		private static ConcurrentDictionary<Guid, Int32> _organisationIds;

		private static void Cont()
		{
			_organisationIds = new ConcurrentDictionary<Guid, int>();
			var id = Guid.NewGuid();
			for (int i= 0; i < 100; i++)
			{
				
				_organisationIds.TryAdd(Guid.NewGuid(), i);
				if (i == 4)
				{
					_organisationIds.TryAdd(id, i);
				}
			}

			var d = _organisationIds[id];
		}

		private async static Task Test()
		{
			await Task.Run(() =>
			{
				for (int i = 0; i < 1000; i++)
				{

				}
			});



			await Task.Run(() =>
			{
				for (int i = 0; i < 1000; i++)
				{

				}
			});
		}

		//	private static void StartLog()
		//	{
		//		List<Task> tt = new List<Task>();
		//		for (int i = 0; i < 1000; i++)
		//		{
		//			//tt.Add(Task.Run(new Action<int>(i() => 
		//			//{
		//			//	var w = new WriteLog();
		//			//	w.WriteError("Test"+i);
		//			//})));

		//		 tt.Add(Task.Factory.StartNew(new Action<object>(
		//(x) =>
		//{
		//	var w = new WriteLog();
		//	w.WriteError("Test"+x);
		//}), i));
		//		}
		//		Task.WhenAll(tt).Wait();
		//	}


		//	private static async void start()
		//	{
		//		string asycPath = @"C:\Karthikeyan\TPL test\asyncfiles";
		//		//CreateFile(path);
		//		Console.WriteLine(DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss"));
		//		Console.WriteLine("Asynchronous creating files started");

		//		//Task.WaitAll(CreateFileAsyncTask(asycPath));
		//		//Task.WhenAll(CreateFileAsyncTask(asycPath));
		//		await CreateFileAsyncTask(asycPath);
		//		Console.WriteLine(DateTime.Now.ToString());
		//		Console.WriteLine(" Asynchronous File creation completed");
		//	}

		//	private static async Task CreateFileAsyncTask(string locationToCreate)
		//	{
		//		List<Task> lsttsk = new List<Task>();

		//		int million = 64;

		//		for (int i = 0; i < million; i++)
		//		{
		//			string fileName = string.Format(@"{0}\test{1}-{2}.txt", locationToCreate, i, DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss"));

		//			Task t = WriteFile(fileName);

		//			lsttsk.Add(t);
		//		}


		//		string dat = DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss");
		//		await Task.WhenAll(lsttsk);

		//	}

		//	private static Task WriteFile(string fileName)
		//	{
		//		return Task.Run(() =>
		//		{
		//			try
		//			{

		//				string text = "A class is the most powerful data type in C#. Like a structure, " +
		//							"a class defines the data and behavior of the data type. ";

		//				using (StreamWriter sw = File.CreateText(fileName))
		//				{
		//					sw.WriteLine(text);
		//				}
		//			}
		//			catch (Exception e)
		//			{

		//			}

		//		});
		//	}

		//	private static void CreateFile(string locationToCreate)
		//	{
		//		int million = 100000;

		//		Console.WriteLine(DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss"));
		//		Console.WriteLine("creating files started");

		//		for (int i = 0; i < million; i++)
		//		{
		//			string fileName = string.Format(@"{0}\test{1}-{2}.txt", locationToCreate, i, DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss"));
		//			string text = "A class is the most powerful data type in C#. Like a structure, " +
		//				   "a class defines the data and behavior of the data type. ";

		//			using (StreamWriter sw = File.CreateText(fileName))
		//			{
		//				sw.WriteLine(text);
		//			}
		//		}
		//		Console.WriteLine(DateTime.Now.ToString());
		//		Console.WriteLine("File creation completed");
		//		Console.ReadLine();

		//	}

		internal sealed class DataflowDemo
		{
			internal DataflowDemo()
			{
				_files = new BufferBlock<string>(new DataflowBlockOptions()
				{
					BoundedCapacity = 100
				});
				_CalculationAction = new ActionBlock<string>(async file =>
				{
					try
					{
						//Console.WriteLine(DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss"));
						await Task.Delay(3000);
						string fileName = string.Format("{0}-{1}.txt", file, DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss"));
						Console.WriteLine(fileName);

						//string fileName = string.Format(@"{0}-{1}.txt", file, Guid.NewGuid().ToString());
						//string text = "A class is the most powerful data type in C#. Like a structure, " +
						//	   "a class defines the data and behavior of the data type. ";

						//// Create a new file     
						//using (StreamWriter sw = File.CreateText(fileName))
						//{
						//	sw.WriteLine(text);
						//}
					}
					catch (Exception e)
					{

					}

				},
				new ExecutionDataflowBlockOptions()
				{
					MaxDegreeOfParallelism = 1,
					BoundedCapacity = 1
				});
				_files.LinkTo(_CalculationAction, new DataflowLinkOptions()
				{
					PropagateCompletion = true
				});
			}
			internal async Task CalculateTotalSizeAsync(string path)
			{
				int million = 1000;
				
				for (int i = 0; i < million; i++)
				{
					string fileName = string.Format("test-{0}", i);

					await _files.SendAsync(fileName);
				}
			}
			internal async Task<long> GetTotalSizeAsync()
			{
				_files.Complete();
				await _files.Completion;
				await _CalculationAction.Completion;
				return _totalSize;
			}
			private long _totalSize;

			private readonly BufferBlock<string> _files;
			private readonly ActionBlock<string> _CalculationAction;
		}
	}

	public class WriteLog
	{
		private static readonly object locker = new object();
		public void WriteError(string errormsg)
		{
			try
			{
				string sortableFileName = string.Format("Log {0}.log", DateTime.Today.ToString("u").Substring(0, 10));

				string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs", sortableFileName);
				if (!Directory.Exists(Path.GetDirectoryName(filePath)))
				{
					Directory.CreateDirectory(Path.GetDirectoryName(filePath));

				}


				string logEntry =
					string.Format(
						"{0} [{1}] [{2}] ", errormsg, DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss:fff"),
						Environment.NewLine);

				lock (locker)
				{
					using (StreamWriter streamWriter = new StreamWriter(filePath, true))
					{
						streamWriter.WriteLine(logEntry);
					}
				}
			}
			catch (Exception e)
			{

			}

		}
	}
}
